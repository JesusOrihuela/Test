import os
import shutil
import uvicorn
import json
import hashlib
from pathlib import Path
from typing import Dict, Any, Optional, List

from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel

from docx2pdf import convert

from app.main import load_llm, format_validation_results, extract_text_from_docx, validate_edn
from app import database

app = FastAPI(title="EDN Document Validator API", description="API for validating Engineering Document Notes against quality criteria")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

llm = None

@app.on_event("startup")
async def startup_event():
    print("Initializing database...")
    database.init_db()
    print("Database initialized.")
    
    global llm
    try:
        server_url = os.environ.get("LLAMA_SERVER_URL", "http://localhost:8000")
        api_key = os.environ.get("LLAMA_API_KEY")
        llm = load_llm(server_url=server_url, api_key=api_key)
        print("Successfully connected to Llama server")
    except Exception as e:
        print(f"Error connecting to Llama server: {e}")
        print("The application will continue in mock mode.")
        llm = None

class SessionListItem(BaseModel):
    session_id: int
    original_filename: str
    session_timestamp: str

class SessionDetail(BaseModel):
    session_id: int
    document_hash: str
    original_filename: str
    file_extension: str
    qa_email: str
    tech_approver_email: str
    session_timestamp: str
    analysis_results: Optional[Dict[str, Any]]
    approval_status: str
    comments: Optional[List[Dict[str, Any]]]

@app.get("/api/sessions", response_model=List[SessionListItem])
async def get_sessions_list():
    """Returns a lightweight list of all validation sessions."""
    return database.get_all_sessions()

@app.get("/api/sessions/{session_id}", response_model=SessionDetail)
async def get_session_details(session_id: int):
    """Returns the full details for a single validation session."""
    details = database.get_session_by_id(session_id)
    if not details:
        raise HTTPException(status_code=404, detail="Session not found")
    return details

@app.get("/api/files/{file_hash_with_ext}")
async def get_document_file(file_hash_with_ext: str):
    """Serves a stored document file for preview."""
    file_path = database.FILES_DIR / file_hash_with_ext
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    if file_path.suffix.lower() == ".docx":
        pdf_path = file_path.with_suffix(".pdf")
        try:
            convert(str(file_path), str(pdf_path))
            return FileResponse(path=str(pdf_path), media_type='application/pdf')
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to convert document for preview: {e}")

    return FileResponse(path=str(file_path), media_type='application/pdf')

class ValidationResponse(BaseModel):
    session_id: int
    raw_results: Dict[str, Any]
    formatted_results: str
    filename: str
    session_details: SessionDetail

@app.post("/api/validate", response_model=ValidationResponse)
async def validate_document(
    file: UploadFile = File(...),
    qa_email: str = Form(...),
    tech_approver_email: str = Form(...)
):
    if not (file.filename.lower().endswith('.docx') or file.filename.lower().endswith('.pdf')):
        raise HTTPException(status_code=400, detail="Unsupported file type.")

    content = await file.read()
    file_hash = hashlib.sha256(content).hexdigest()
    file_extension = Path(file.filename).suffix
    
    hashed_filename = f"{file_hash}{file_extension}"
    file_path = database.FILES_DIR / hashed_filename
    with open(file_path, "wb") as buffer:
        buffer.write(content)

    database.add_document_if_not_exists(
        file_hash, file.filename, file_extension, len(content)
    )
    
    session_id = database.create_validation_session(
        file_hash, qa_email, tech_approver_email
    )

    if not llm:
        mock_file_path = Path(__file__).parent / "app" / "mock.json"
        with open(mock_file_path, 'r') as f:
            analysis_results = json.load(f)
    else:
        if not file.filename.lower().endswith('.docx'):
            raise HTTPException(status_code=400, detail="AI validation requires a .docx file.")
        
        doc_data = extract_text_from_docx(file_path)
        if not doc_data:
            raise HTTPException(status_code=500, detail="Failed to extract text from DOCX.")
            
        from app.main import load_edn_criteria
        criteria = load_edn_criteria()
        analysis_results = validate_edn(llm, doc_data, criteria)

    database.update_session_results(session_id, analysis_results)
    formatted_results = format_validation_results(analysis_results)
    session_details = database.get_session_by_id(session_id)
    
    return {
        "session_id": session_id,
        "raw_results": analysis_results,
        "formatted_results": formatted_results,
        "filename": file.filename,
        "session_details": session_details,
    }

@app.post("/api/sessions/{session_id}/approve")
async def approve_session(session_id: int):
    database.update_approval_status(session_id, "approved")
    return {"status": "success", "session_id": session_id, "new_status": "approved"}

@app.post("/api/sessions/{session_id}/reject")
async def reject_session(session_id: int):
    database.update_approval_status(session_id, "rejected")
    return {"status": "success", "session_id": session_id, "new_status": "rejected"}

class CommentBody(BaseModel):
    user: str
    text: str

@app.post("/api/sessions/{session_id}/comment")
async def post_comment(session_id: int, comment: CommentBody):
    database.add_comment_to_session(session_id, comment.user, comment.text)
    return {"status": "success", "message": "Comment added."}
    
@app.post("/api/viewfile")
async def get_viewable_file(file: UploadFile = File(...)):
    filename = Path(file.filename).name
    temp_dir = Path("temp_uploads")
    temp_dir.mkdir(exist_ok=True)
    file_path = temp_dir / filename
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    output_path = file_path
    
    if file_path.suffix.lower() == ".docx":
        try:
            pdf_path = file_path.with_suffix(".pdf")
            convert(str(file_path), str(pdf_path))
            output_path = pdf_path
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to convert document: {e}")

    if not output_path.exists():
        raise HTTPException(status_code=404, detail="File not found after processing.")

    return FileResponse(
        path=str(output_path),
        media_type='application/pdf',
        filename=output_path.name
    )

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=5000, reload=True)