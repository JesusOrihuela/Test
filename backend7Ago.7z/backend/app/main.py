import os
import os
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
import docx
from .model import AIModel
from .prompts import get_system_prompt

def load_llm(server_url: str = None, api_key: str = None):
    """
    Load the LLM model from a server
    
    Args:
        server_url: URL of the Llama server (defaults to env var or http://localhost:8080)
        api_key: API key for the server (defaults to env var or None)
    """
    try:
        # Use parameters or fall back to environment variables
        server_url = server_url or os.environ.get("LLAMA_SERVER_URL", "http://localhost:8000")
        api_key = api_key or os.environ.get("LLAMA_API_KEY")
        
        print(f"Connecting to Llama server at: {server_url}")
        model = AIModel(server_url=server_url, api_key=api_key)
        return model
    except Exception as e:
        print(f"Error connecting to Llama server: {e}")
        raise

def load_edn_criteria() -> Dict[str, Any]:
    """
    Load EDN validation criteria from JSON file
    """
    try:
        criteria_file = Path(__file__).parent / "criteria.json"
        
        # If criteria file doesn't exist, create a default one
        if not criteria_file.exists():
            default_criteria = {
                "criteria": [
                    {
                        "id": 1,
                        "name": "Document Format",
                        "description": "Document follows the standard EDN template"
                    },
                    {
                        "id": 2,
                        "name": "Document Content",
                        "description": "Content is complete and clear"
                    },
                    {
                        "id": 3,
                        "name": "Technical Accuracy",
                        "description": "Technical specifications are accurate"
                    }
                ]
            }
            
            with open(criteria_file, "w") as f:
                json.dump(default_criteria, f, indent=2)
            
            return default_criteria
        
        # Load existing criteria file
        with open(criteria_file, "r") as f:
            return json.load(f)
    
    except Exception as e:
        print(f"Error loading criteria: {e}")
        # Return default criteria if loading fails
        return {
            "criteria": [
                {
                    "id": 1,
                    "name": "Document Format",
                    "description": "Document follows standard format"
                },
                {
                    "id": 2,
                    "name": "Document Content",
                    "description": "Content is complete and clear"
                },
                {
                    "id": 3,
                    "name": "Technical Accuracy",
                    "description": "Technical accuracy is maintained"
                }
            ]
        }

def extract_text_from_docx(file_path: Path) -> Dict[str, Any]:
    """
    Extract text and metadata from a DOCX file
    """
    try:
        doc = docx.Document(file_path)
        
        # Extract paragraphs
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        
        # Extract tables
        tables = []
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = [cell.text for cell in row.cells]
                table_data.append(row_data)
            tables.append(table_data)
        
        # Basic metadata
        metadata = {
            "filename": file_path.name,
            "page_count": len(doc.sections),
            "paragraph_count": len(paragraphs)
        }
        
        return {
            "metadata": metadata,
            "paragraphs": paragraphs,
            "tables": tables,
            "full_text": "\n".join(paragraphs)
        }
    
    except Exception as e:
        print(f"Error extracting text from document: {e}")
        return None

def validate_criterion(llm: AIModel, doc_data: Dict[str, Any], criterion: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate a single criterion against the document
    """
    system_prompt = get_system_prompt()
    
    prompt = f"""
    DOCUMENT TO VALIDATE:
    {doc_data['full_text'][:3000]}  # Limit to first 3000 chars for performance
    
    CRITERION TO VALIDATE:
    {criterion['name']}: {criterion['description']}
    
    Validate if this document meets the criterion. 
    First line must be PASS or FAIL, followed by your detailed explanation.
    """
    
    response = llm.query(prompt, system_prompt=system_prompt, max_tokens=1024)
    
    # Parse result
    lines = response.strip().split('\n')
    result = "FAIL"
    explanation = response
    
    if lines and lines[0]:
        first_line = lines[0].strip().upper()
        if "PASS" in first_line:
            result = "PASS"
        explanation = '\n'.join(lines[1:]) if len(lines) > 1 else "No detailed explanation provided."
    
    return {
        "id": criterion["id"],
        "criterion": criterion["name"],
        "description": criterion["description"],
        "result": result,
        "explanation": explanation,
        "raw_response": response
    }

def validate_edn(llm: AIModel, doc_data: Dict[str, Any], criteria_data: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
    """
    Validate document against all criteria
    """
    results = {
        "metadata": doc_data["metadata"],
        "criteria_results": []
    }
    
    # Process each criterion in the criteria list
    if "criteria" in criteria_data:
        for criterion in criteria_data["criteria"]:
            print(f"Validating criterion: {criterion['name']}")
            result = validate_criterion(llm, doc_data, criterion)
            results["criteria_results"].append(result)
    
    # Calculate summary statistics
    total_criteria = len(results["criteria_results"])
    passed_criteria = sum(1 for result in results["criteria_results"] if result["result"] == "PASS")
    
    results["summary"] = {
        "total_criteria": total_criteria,
        "passed_criteria": passed_criteria,
        "pass_percentage": round((passed_criteria / total_criteria * 100) if total_criteria > 0 else 0, 2)
    }
    
    return results
    

def format_validation_results(results: Dict[str, Any]) -> str:
    """
    Format validation results into a readable string
    """
    output = []
    
    # Add header
    output.append("=" * 80)
    output.append(f"EDN VALIDATION REPORT: {results['metadata']['filename']}")
    output.append("=" * 80)
    
    # Add summary
    summary = results["summary"]
    output.append(f"\nSUMMARY:")
    output.append(f"Total Criteria: {summary['total_criteria']}")
    output.append(f"Passed Criteria: {summary['passed_criteria']}")
    output.append(f"Pass Percentage: {summary['pass_percentage']}%")
    output.append("\n" + "-" * 80)
    
    # Add detailed results for each criterion
    output.append(f"\nDETAILED RESULTS:")
    
    for i, result in enumerate(results["criteria_results"], 1):
        status = "✅ PASS" if result["result"] == "PASS" else "❌ FAIL"
        output.append(f"\n{i}. {result['criterion']} - {status}")
        output.append(f"   Description: {result['description']}")
        output.append(f"   Explanation: {result['explanation'].strip()}")
        output.append("")
    
    return "\n".join(output)
