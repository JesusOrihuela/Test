import sqlite3
import json
from pathlib import Path
from datetime import datetime

DB_DIR = Path(__file__).parent.parent / "data"
DB_PATH = DB_DIR / "database.db"
FILES_DIR = DB_DIR / "files"

def init_db():
    """Initializes the database and creates tables if they don't exist."""
    DB_DIR.mkdir(exist_ok=True)
    FILES_DIR.mkdir(exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        
        # Table for unique document files
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                hash TEXT PRIMARY KEY,
                original_filename TEXT NOT NULL,
                file_extension TEXT NOT NULL,
                filesize_bytes INTEGER NOT NULL,
                first_uploaded_at TEXT NOT NULL
            )
        """)
        
        # Table for each validation session/project
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS validation_sessions (
                session_id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_hash TEXT NOT NULL,
                qa_email TEXT NOT NULL,
                tech_approver_email TEXT NOT NULL,
                session_timestamp TEXT NOT NULL,
                analysis_results TEXT,
                approval_status TEXT NOT NULL DEFAULT 'pending',
                approval_timestamp TEXT,
                comments TEXT,
                FOREIGN KEY (document_hash) REFERENCES documents(hash)
            )
        """)
        conn.commit()

def add_document_if_not_exists(file_hash: str, filename: str, ext: str, size: int):
    """Adds a document to the database if its hash is unique."""
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT hash FROM documents WHERE hash = ?", (file_hash,))
        if cursor.fetchone() is None:
            timestamp = datetime.utcnow().isoformat()
            cursor.execute(
                "INSERT INTO documents (hash, original_filename, file_extension, filesize_bytes, first_uploaded_at) VALUES (?, ?, ?, ?, ?)",
                (file_hash, filename, ext, size, timestamp)
            )
            conn.commit()

def create_validation_session(doc_hash: str, qa_email: str, tech_approver: str) -> int:
    """Creates a new validation session and returns its ID."""
    with sqlite3.connect(DB_PATH) as conn:
        timestamp = datetime.utcnow().isoformat()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO validation_sessions (document_hash, qa_email, tech_approver_email, session_timestamp) VALUES (?, ?, ?, ?)",
            (doc_hash, qa_email, tech_approver, timestamp)
        )
        conn.commit()
        return cursor.lastrowid

def update_session_results(session_id: int, results: dict):
    """Saves the AI/mock analysis results to a session."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "UPDATE validation_sessions SET analysis_results = ? WHERE session_id = ?",
            (json.dumps(results), session_id)
        )
        conn.commit()

def update_approval_status(session_id: int, status: str):
    """Updates the approval status and timestamp for a session."""
    with sqlite3.connect(DB_PATH) as conn:
        timestamp = datetime.utcnow().isoformat()
        conn.execute(
            "UPDATE validation_sessions SET approval_status = ?, approval_timestamp = ? WHERE session_id = ?",
            (status, timestamp, session_id)
        )
        conn.commit()

def add_comment_to_session(session_id: int, user: str, text: str):
    """Adds a new comment to a session's comment log."""
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT comments FROM validation_sessions WHERE session_id = ?", (session_id,))
        result = cursor.fetchone()
        
        comments = json.loads(result[0]) if result and result[0] else []
        
        new_comment = {
            "user": user,
            "text": text,
            "timestamp": datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        }
        comments.append(new_comment)
        
        conn.execute(
            "UPDATE validation_sessions SET comments = ? WHERE session_id = ?",
            (json.dumps(comments), session_id)
        )
        conn.commit()

def get_all_sessions():
    """Retrieves a list of all sessions for the sidebar."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.session_id, d.original_filename, s.session_timestamp
            FROM validation_sessions s
            JOIN documents d ON s.document_hash = d.hash
            ORDER BY s.session_timestamp DESC
        """)
        sessions = [dict(row) for row in cursor.fetchall()]
        return sessions

def get_session_by_id(session_id: int):
    """Retrieves all details for a specific session."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT
                s.session_id,
                s.document_hash,
                d.original_filename,
                d.file_extension,
                s.qa_email,
                s.tech_approver_email,
                s.session_timestamp,
                s.analysis_results,
                s.approval_status,
                s.comments
            FROM validation_sessions s
            JOIN documents d ON s.document_hash = d.hash
            WHERE s.session_id = ?
        """, (session_id,))
        session_data = cursor.fetchone()
        if session_data:
            data = dict(session_data)
            data['analysis_results'] = json.loads(data['analysis_results']) if data['analysis_results'] else None
            data['comments'] = json.loads(data['comments']) if data['comments'] else []
            return data
        return None