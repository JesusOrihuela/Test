import http
import os
import time
import json
import requests
import sys
from pathlib import Path
from typing import Optional, Union, Generator

class AIModel:
   def __init__(self,
                server_url: str = "http://localhost:8000",
                api_key: str = None,
                model_path: str = None,
                n_ctx: int = 8192,
                n_gpu_layers: int = 20,
                n_threads: int = 8):

      self.server_url = server_url
      self.api_key = api_key
      self.headers = {"Content-Type": "application/json"}
      if api_key:
         self.headers["Authorization"] = f"Bearer {api_key}"
      
      self.check_server_conn()

   def check_server_conn(self):
      """
      Check the connection to the model server.
      """
      try:
         response = requests.get(f"{self.server_url}/health", headers=self.headers, timeout=5)
         response.raise_for_status()
         print(f"Server is healthy at {self.server_url}")
      except requests.RequestException as e:
         print(f"Error checking server connection: {e}")
         print(f"Make sure the Llama server is running at {self.server_url}")
         print("You can start it with 'make start-model-server'")
         # Don't exit to allow more graceful handling
         raise ConnectionError(f"Failed to connect to Llama server at {self.server_url}")

   def query(self, prompt: str, system_prompt: str = None, max_tokens: int = 512, temperature: float = 0.2) -> str:
      """
      Query the model with a prompt and return the response.
      """
      messages = []
      if system_prompt:
         messages.append({"role": "system", "content": system_prompt})
      
      # Add user prompt
      messages.append({"role": "user", "content": prompt})
      
      try:
         payload = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
         }
         response = requests.post(
            f"{self.server_url}/v1/chat/completions",
            headers=self.headers,
            data=json.dumps(payload),
            timeout=60
         )
         
         response.raise_for_status()
         result = response.json()
         return result["choices"][0]["message"]["content"]
      except Exception as e:
         print(f"Error querying model: {e}")
         raise
   
   def stream(self, prompt: str, system_prompt: str = None, max_tokens: int = 512, temperature: float = 0.2) -> Generator[str, None, None]:
      """
      Stream the model's response.
      """
      messages = []
      if system_prompt:
         messages.append({"role": "system", "content": system_prompt})
      
      # Add user prompt
      messages.append({"role": "user", "content": prompt})
      
      try:
         payload = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True
         }
         
         response = requests.post(
            f"{self.server_url}/v1/chat/completions",
            headers=self.headers,
            data=json.dumps(payload),
            stream=True,
            timeout=60
         )
         response.raise_for_status()
         
         # Process streaming response
         token_count = 0
         for line in response.iter_lines():
            if line:
               line = line.decode('utf-8')
               # Skip the "data: " prefix and empty lines
               if line.startswith('data: ') and line != 'data: [DONE]':
                  json_str = line[6:]  # Remove 'data: ' prefix
                  try:
                     data = json.loads(json_str)
                     content = data.get("choices", [{}])[0].get("delta", {}).get("content", "")
                     if content:
                        token_count += 1
                        if token_count % 20 == 0:
                           print(f"Streaming token #{token_count}: '{content[:10]}...'")
                        yield content
                  except json.JSONDecodeError:
                     continue
         
         print(f"Streaming complete, generated {token_count} tokens")
      except Exception as e:
         print(f"Error streaming model response: {e}")
         raise