import { CheckSquare, CircleSlash, Eye } from 'lucide-react';
import mockResultsData from '../assets/mock-results.json';
import React, { useState } from 'react';
import { InlineProcessingLoader } from './InlineProcessingLoader';

interface Criterion {
  id: string | number;
  name: string;
  description: string;
  result: boolean | null;
  fullExplanation?: string;
}

interface ResultsDisplayProps {
  analysisComplete: boolean;
  results: { criteria: Criterion[] } | null;
  isProcessing?: boolean;
}

export function ResultsDisplay({ 
  analysisComplete, 
  results, 
  isProcessing = false
}: ResultsDisplayProps) {
  const criteriaToDisplay = results?.criteria || mockResultsData.criteria.map((c: any) => ({ ...c, result: null }));
  
  const [expandedCriteria, setExpandedCriteria] = useState<Set<string | number>>(new Set());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCriterion, setSelectedCriterion] = useState<Criterion | null>(null);
  
  const toggleCriterion = (id: string | number) => {
    setExpandedCriteria(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      return newSet;
    });
  };
  
  // This function now correctly stops the event from bubbling up to the parent li
  const openCriterionModal = (criterion: Criterion, event: React.MouseEvent) => {
    event.stopPropagation(); // <-- THIS IS THE FIX
    setSelectedCriterion(criterion);
    setIsModalOpen(true);
  };
  
  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedCriterion(null);
  };

  const totalEvaluatedCriteria = criteriaToDisplay.filter(c => c.result !== null).length;
  const passedCriteria = criteriaToDisplay.filter(c => c.result === true).length;

  return (
    <>
      <div className="bg-white p-4 md:p-5 rounded-md border border-gray-200 shadow-sm flex flex-col h-full">
        <div className="flex justify-between items-center flex-shrink-0">
          <h2 className="text-2xl font-bold text-gray-800">Validation Results</h2>
          {analysisComplete && totalEvaluatedCriteria > 0 && (
            <div className="text-lg font-semibold">
              <span className={passedCriteria === totalEvaluatedCriteria ? 'text-green-600' : 'text-red-600'}>
                {passedCriteria}/{totalEvaluatedCriteria}
              </span>
            </div>
          )}
        </div>
        <hr className="my-3 border-gray-300 flex-shrink-0" />

        {isProcessing && <InlineProcessingLoader />}

        <div className="flex-grow space-y-2 overflow-y-auto pr-2 h-[45vh]">
          <ul className="space-y-2">
            {criteriaToDisplay.map((criterion, index) => (
              <li
                key={criterion.id}
                className={`transition-all duration-300 rounded-md 
                  ${criterion.result === true ? 'bg-green-50' : 
                    criterion.result === false ? 'bg-red-50' : 
                    'bg-gray-50'} 
                  hover:bg-opacity-80 cursor-pointer`}
                onClick={() => toggleCriterion(criterion.id)}
              >
                <div className="flex items-center p-2">
                  <span className="text-sm text-gray-500 w-6 text-center flex-shrink-0">{index + 1}</span>
                  <p className="font-semibold text-gray-800 text-sm md:text-base ml-2">{criterion.name}</p>
                  <span className="ml-2 text-gray-400">&gt;</span>
                  
                  <div className="ml-auto flex items-center gap-4 pl-2">
                    <button
                      className="p-1 rounded-full text-blue-600 hover:bg-blue-100"
                      onClick={(e) => openCriterionModal(criterion, e)}
                      title="View Details"
                    >
                      <Eye size={18} />
                    </button>
                    {criterion.result === true && <CheckSquare size={20} className="text-green-500" />}
                    {criterion.result === false && <CircleSlash size={20} className="text-red-500" />}
                  </div>
                </div>
                {expandedCriteria.has(criterion.id) && (
                  <div className="pb-2 px-4 ml-8 border-l-2 border-gray-200">
                    <p className="text-sm text-gray-600">{criterion.description}</p>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {isModalOpen && selectedCriterion && (
        <div 
          className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50"
          onClick={closeModal}
        >
          <div 
            className="bg-white rounded-lg shadow-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold text-gray-800">{selectedCriterion.name}</h3>
              <button onClick={closeModal} className="text-gray-500 hover:text-gray-700 font-bold text-xl"> &times; </button>
            </div>
            <p className="text-gray-800 mb-4">{selectedCriterion.description}</p>
            {selectedCriterion.fullExplanation && (
              <div className="bg-gray-50 p-4 rounded">
                <h4 className="font-semibold text-gray-700 mb-2">Analysis:</h4>
                <p className="text-gray-800 whitespace-pre-wrap">{selectedCriterion.fullExplanation}</p>
              </div>
            )}
            <div className="mt-6 text-right">
              <button onClick={closeModal} className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Close</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}