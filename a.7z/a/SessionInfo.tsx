import { Users } from 'lucide-react';

interface SessionInfoProps {
  qaEmail: string;
  techApproverEmail: string;
  onAssignRoles: () => void;
}

export function SessionInfo({ qaEmail, techApproverEmail, onAssignRoles }: SessionInfoProps) {
  const rolesAssigned = qaEmail && techApproverEmail;

  return (
    <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div className="flex items-start">
        <Users size={24} className="text-bh-green mr-4 mt-1 flex-shrink-0" />
        <div>
          <h3 className="font-semibold text-gray-800 text-base lg:text-lg">Assigned Roles</h3>
          {rolesAssigned ? (
            <div className="text-sm md:text-base text-gray-600 mt-1">
              <p><span className="font-medium">QA:</span> {qaEmail}</p>
              <p><span className="font-medium">Tech Approver:</span> {techApproverEmail}</p>
            </div>
          ) : (
            <p className="text-sm md:text-base text-gray-500 mt-1">Roles have not been assigned for this session.</p>
          )}
        </div>
      </div>
      <button
        onClick={onAssignRoles}
        className="text-sm md:text-base font-semibold text-bh-green hover:underline self-start sm:self-center"
      >
        {rolesAssigned ? 'Change' : 'Assign Roles'}
      </button>
    </div>
  );
}