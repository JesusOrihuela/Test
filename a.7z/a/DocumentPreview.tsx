import { useEffect, useState } from 'react';
import { FileQuestion, LoaderCircle } from 'lucide-react';

interface DocumentPreviewProps {
  file: File | null;
}

export function DocumentPreview({ file }: DocumentPreviewProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!file) {
      setPreviewUrl(null);
      setIsLoading(false);
      setError(null);
      return;
    }

    let objectUrl: string | null = null;
    const cleanup = () => {
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
    };

    const generatePreview = async () => {
      setIsLoading(true);
      setError(null);
      cleanup();

      try {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch('http://localhost:5000/api/viewfile', {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.detail || 'Failed to generate document preview.');
        }

        const pdfBlob = await response.blob();
        objectUrl = URL.createObjectURL(pdfBlob);
        setPreviewUrl(objectUrl);

      } catch (err) {
        console.error("Error generating preview:", err);
        setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        setPreviewUrl(null);
      } finally {
        setIsLoading(false);
      }
    };

    generatePreview();

    return cleanup;
    
  }, [file]);

  return (
    <div className="bg-white p-2 md:p-4 rounded-md border border-gray-200 shadow-sm w-full h-full flex flex-col">
      <div className="w-full flex-grow rounded border border-gray-200 bg-gray-50 flex items-center justify-center">
        {isLoading && (
          <div className="flex flex-col items-center text-bh-gray">
            <LoaderCircle size={48} className="animate-spin" />
            <p className="mt-4 font-semibold">Generating Preview...</p>
            <p className="mt-1 text-sm">Converting document for viewing.</p>
          </div>
        )}

        {error && !isLoading && (
          <div className="text-center text-red-600 p-4">
            <p className="font-bold">Preview Error</p>
            <p className="text-sm mt-1">{error}</p>
          </div>
        )}

        {previewUrl && !isLoading && (
          <iframe
            src={previewUrl}
            className="w-full h-full"
            title="Document Preview"
          />
        )}

        {!file && !isLoading && !error && (
          <div className="flex flex-col items-center justify-center text-center text-bh-gray">
            <FileQuestion size={64} />
            <p className="mt-4 text-lg font-semibold">No document has been uploaded yet</p>
            <p className="mt-1 text-sm">Upload a file to see the preview here.</p>
          </div>
        )}
      </div>
    </div>
  );
}