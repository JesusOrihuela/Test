import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export function Header() {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="relative flex items-center justify-between h-16 px-6 bg-bh-dark-green text-white shadow-lg w-full">
      <div className="flex items-center">
        <img src="/logo.png" alt="Panametrics Logo" className="h-8" />
        <div className="h-full flex items-center ml-4 pl-4 border-l border-gray-500">
          <span className="text-2xl lg:text-3xl font-semi-bold">EDN Hub</span>
        </div>
      </div>
      
      {location.pathname === '/' && (
        <>
          <div className="hidden md:block">
            <a
              href="/FAQs"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-md font-medium text-gray-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              <span>Download Templates</span>
            </a>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-md hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-white"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </>
      )}

      {isMenuOpen && location.pathname === '/' && (
        <div className="md:hidden absolute top-16 left-0 w-full bg-bh-dark-green shadow-lg z-40">
          <a
            href="/FAQs"
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full px-6 py-4 text-left font-medium text-gray-200 hover:bg-white/10"
            onClick={() => setIsMenuOpen(false)}
          >
            Download Templates
          </a>
        </div>
      )}
    </header>
  );
}