import os
from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from pathlib import Path
import shutil
import uvicorn
from typing import Dict, Any, Optional
from pydantic import BaseModel
import json
import re
from docx2pdf import convert # Requires Microsoft Word / LibreOffice installed in the server environment

# Import from the app module
from app.main import load_llm, load_edn_criteria, extract_text_from_docx, validate_edn, format_validation_results

app = FastAPI(title="EDN Document Validator API", 
              description="API for validating Engineering Document Notes against quality criteria")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development - restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create temp directory for uploads
temp_dir = Path("temp_uploads")
temp_dir.mkdir(exist_ok=True)

# Global variable to hold the model
llm = None

# Function to load the model (called at startup)
def load_model():
    global llm
    try:
        llm = load_llm()
        print("Model loaded successfully and ready for API requests")
    except Exception as e:
        print(f"Error loading model: {e}")
        llm = None

# Load the model on startup (only in the main process)
@app.on_event("startup")
async def startup_event():
    load_model()


@app.post("/api/validate/stream")
async def stream_validation_upload(file: UploadFile = File(...)):
    """
    Upload a file for streaming validation
    
    - **file**: DOCX file to validate
    
    Returns a success message
    """
    if not llm:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    if not file.filename.endswith('.docx'):
        raise HTTPException(status_code=400, detail="Only .docx files are supported")
    
    # Save uploaded file temporarily
    file_path = temp_dir / file.filename
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    # Store the file path for the GET request
    app.state.last_uploaded_file = file_path
    
    return {"status": "success", "message": "File uploaded successfully"}


@app.get("/api/validate/stream")
async def stream_validation_results():
    """
    Stream validation results as they're generated
    
    Returns a streaming response with validation updates
    """
    if not llm:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    # Get the file path from app state
    if not hasattr(app.state, "last_uploaded_file"):
        raise HTTPException(status_code=400, detail="No file has been uploaded")
    
    file_path = app.state.last_uploaded_file
    
    async def generate():
        try:
            # Load criteria
            criteria_data = load_edn_criteria()
            print(f"Loaded {len(criteria_data['criteria'])} validation criteria")
            
            # Extract document content
            doc_data = extract_text_from_docx(file_path)
            print(f"Extracted document content from {file_path.name}, length: {len(doc_data.get('full_text', ''))}")
            
            if not doc_data:
                print("Error: Failed to extract document data")
                yield f"data: {json.dumps({'type': 'error', 'content': 'Failed to extract document data'})}\n\n"
                return
            
            # Prepare document for validation
            document_content = doc_data.get("full_text", "")
            print(f"Document content length: {len(document_content)}")
            print(f"First 100 chars of document: {document_content[:100]}...")
            
            # Build the validation prompt
            validation_prompt = "Validate the following document against these criteria:\n\n"
            
            # Send initial criteria information to client
            for i, criterion in enumerate(criteria_data["criteria"], 1):
                validation_prompt += f"Criterion {i}: {criterion['name']}\n"
                validation_prompt += f"Description: {criterion['description']}\n\n"
                
                # Tell the client about this criterion
                data_dict = {
                    'type': 'criteria_info',
                    'id': str(i),
                    'name': criterion['name'],
                    'description': criterion['description']
                }
                yield f"data: {json.dumps(data_dict)}\n\n"
            
            # Add document content to prompt
            validation_prompt += f"DOCUMENT CONTENT:\n{document_content}\n\n"
            validation_prompt += "For each criterion, explain your analysis and then clearly state PASS or FAIL."
            
            # Set up more efficient criteria detection
            buffer = ""
            processed_criteria = set()
            last_check_position = 0
            check_frequency = 20  # Check for results every 20 tokens
            
            print(f"Starting streaming validation with prompt length: {len(validation_prompt)}")
            print(f"Validating document against {len(criteria_data['criteria'])} criteria")
            
            # Stream the validation process
            token_count = 0
            for token in llm.stream(validation_prompt, max_tokens=4096):
                token_count += 1
                if token_count % 50 == 0:  # Print status every 50 tokens
                    print(f"Streaming token #{token_count}, buffer size: {len(buffer)}")
                
                # Add to our buffer
                buffer += token
                
                # Only send every few tokens to reduce network overhead
                if token_count % 3 == 0 or len(token) > 5:  # Send every 3rd token or longer tokens
                    token_data = {'type': 'token', 'content': token}
                    yield f"data: {json.dumps(token_data)}\n\n"
                
                # Add to our buffer for pattern matching
                buffer += token
                
                # Only check for results periodically to improve performance
                if token_count % check_frequency == 0:
                    # Only check new content since last check
                    new_content = buffer[last_check_position:].lower()
                    last_check_position = len(buffer)
                    
                    # Check for results for each criterion
                    for i in range(1, len(criteria_data["criteria"]) + 1):
                        criterion_id = str(i)
                        if criterion_id not in processed_criteria:
                            criterion_marker = f"criterion {criterion_id}"
                            
                            # Check for PASS
                            if criterion_marker in new_content and "pass" in new_content:
                                # Verify they're close to each other (within 50 chars)
                                criterion_pos = new_content.find(criterion_marker)
                                pass_pos = new_content.find("pass")
                                
                                if abs(criterion_pos - pass_pos) < 50:
                                    processed_criteria.add(criterion_id)
                                    print(f"✅ Detected PASS for criterion {criterion_id}")
                                    pass_data = {
                                        'type': 'criteria_update',
                                        'id': criterion_id,
                                        'result': True
                                    }
                                    yield f"data: {json.dumps(pass_data)}\n\n"
                            
                            # Check for FAIL
                            elif criterion_marker in new_content and "fail" in new_content:
                                criterion_pos = new_content.find(criterion_marker)
                                fail_pos = new_content.find("fail")
                                
                                if abs(criterion_pos - fail_pos) < 50:
                                    processed_criteria.add(criterion_id)
                                    print(f"❌ Detected FAIL for criterion {criterion_id}")
                                    fail_data = {
                                        'type': 'criteria_update',
                                        'id': criterion_id,
                                        'result': False
                                    }
                                    yield f"data: {json.dumps(fail_data)}\n\n"
                
                # More efficient buffer management
                if len(buffer) > 3000:
                    # Trim buffer more aggressively
                    buffer = buffer[-1500:]
                    last_check_position = max(0, last_check_position - 1500)
                
                # Less frequent debug output to reduce overhead
                if token_count % 200 == 0:
                    print(f"Progress: {token_count} tokens, buffer size: {len(buffer)}")
                    
                    # Check if any criteria found so far
                    if processed_criteria:
                        print(f"Found results for criteria: {sorted(processed_criteria)}")
                    else:
                        print("No criteria results detected yet")
            
            # Mark completion
            print(f"✓ Streaming completed, processed {token_count} tokens")
            print(f"✓ Results: {len(processed_criteria)}/{len(criteria_data['criteria'])} criteria evaluated")
            complete_data = {'type': 'complete'}
            yield f"data: {json.dumps(complete_data)}\n\n"
            
        except Exception as e:
            import traceback
            error_info = traceback.format_exc()
            print(f"Streaming error: {error_info}")
            print(f"Exception type: {type(e).__name__}")
            print(f"Exception message: {str(e)}")
            error_data = {'type': 'error', 'content': str(e)}
            yield f"data: {json.dumps(error_data)}\n\n"
    
    return StreamingResponse(generate(), media_type="text/event-stream")


@app.post("/api/viewfile")
async def get_viewable_file(file: UploadFile = File(...)):
    """
    Accepts a DOCX or PDF, converts DOCX to PDF if necessary,
    and returns a file response that can be displayed in a browser.
    """
    # Sanitize filename to prevent directory traversal attacks
    filename = Path(file.filename).name
    file_path = temp_dir / filename
    
    # Save the uploaded file
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    output_path = file_path
    
    # Check if conversion is needed
    if file_path.suffix.lower() == ".docx":
        try:
            print(f"Converting {filename} to PDF...")
            pdf_path = file_path.with_suffix(".pdf")
            convert(str(file_path), str(pdf_path))
            output_path = pdf_path
            print("Conversion successful.")
        except Exception as e:
            print(f"Error converting DOCX to PDF: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to convert document: {e}")

    if not output_path.exists():
        raise HTTPException(status_code=404, detail="File not found after processing.")

    # Return the PDF file, which the browser can display
    return FileResponse(
        path=str(output_path),
        media_type='application/pdf',
        filename=output_path.name
    )

class ValidationResponse(BaseModel):
    raw_results: Dict[str, Any]
    formatted_results: str
    filename: str

@app.post("/api/validate", response_model=ValidationResponse)
async def validate_document(file: UploadFile = File(...)):
    """
    Validate a document against EDN criteria
    
    - **file**: DOCX file to validate
    
    Returns validation results in both raw and formatted form
    """
    if not llm:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    if not file.filename.endswith('.docx'):
        raise HTTPException(status_code=400, detail="Only .docx files are supported")
    
    # Save uploaded file temporarily
    file_path = temp_dir / file.filename
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    try:
        # Load criteria
        criteria_data = load_edn_criteria()
        
        # Extract document content
        doc_data = extract_text_from_docx(file_path)
        
        if not doc_data:
            raise HTTPException(status_code=500, detail="Failed to extract document data")
        
        # Validate document
        validation_results = validate_edn(llm, doc_data, criteria_data)
        
        # Format results for display
        formatted_results = format_validation_results(validation_results)
        
        # Save results to file
        result_path = file_path.with_suffix('.validation.txt')
        with open(result_path, 'w', encoding='utf-8') as f:
            f.write(formatted_results)
        
        # Return both raw and formatted results
        return {
            "raw_results": validation_results,
            "formatted_results": formatted_results,
            "filename": file.filename
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing document: {str(e)}")

# For cleaning up files after a delay
@app.post("/api/cleanup")
async def cleanup_files(background_tasks: BackgroundTasks):
    """Clean up temporary files"""
    def remove_temp_files():
        for file_path in temp_dir.glob("*"):
            try:
                if file_path.is_file():
                    file_path.unlink()
            except Exception as e:
                print(f"Error removing file {file_path}: {e}")
    
    background_tasks.add_task(remove_temp_files)
    return {"message": "Cleanup scheduled"}

# Serve the React frontend in production
@app.get("/{full_path:path}")
async def serve_frontend(full_path: str):
    static_folder = Path("../frontend/edn-validator/build")
    file_path = static_folder / full_path
    
    if full_path == "" or not file_path.exists():
        return FileResponse(static_folder / "index.html")
    
    return FileResponse(file_path)

if __name__ == "__main__":
    # Run with uvicorn for better performance
    uvicorn.run("server:app", host="0.0.0.0", port=5000, reload=True)
