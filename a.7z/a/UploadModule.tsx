import { UploadCloud, CheckCircle, FileText } from 'lucide-react';

interface UploadModuleProps {
  selectedFile: File | null;
  onUploadClick: () => void;
  onProcess: () => void;
  isLocked: boolean;
  processDisabled: boolean;
}

export function UploadModule({ selectedFile, onUploadClick, onProcess, isLocked, processDisabled }: UploadModuleProps) {
  const buttonBaseStructure = "w-full md:w-64 py-2 border-2 rounded font-semibold transition-all flex items-center justify-center text-sm md:text-base";
  const whiteButton = "bg-white text-bh-green border-bh-green hover:bg-bh-green hover:text-white disabled:bg-gray-100 disabled:text-gray-400 disabled:border-gray-300 disabled:cursor-not-allowed";
  const greenButton = isLocked
    ? "bg-gray-100 text-gray-400 border-gray-300 cursor-not-allowed"
    : "bg-bh-green text-white border-bh-green hover:bg-white hover:text-bh-green cursor-pointer";

  return (
    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
      <div>
        <div>
          <button
            type="button"
            onClick={onUploadClick}
            disabled={isLocked}
            className={`${buttonBaseStructure} ${greenButton}`}
          >
            <UploadCloud size={20} className="mr-2" />
            <span>Upload</span>
          </button>
          <p className="text-xs md:text-sm text-bh-gray mt-1">Accepted Format: .DOCX and .PDF files</p>
        </div>

        {selectedFile && (
          <div className="flex items-center gap-2 text-sm md:text-base text-gray-700 mt-4">
            <CheckCircle size={20} className="text-bh-green" />
            <FileText size={16} className="text-bh-gray" />
            <span>{selectedFile.name}</span>
          </div>
        )}
      </div>

      <div>
        <button
          onClick={onProcess}
          disabled={processDisabled}
          className={`${buttonBaseStructure} ${whiteButton}`}
        >
          Process Document
        </button>
      </div>
    </div>
  );
}