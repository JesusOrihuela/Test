import { useState, useRef } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Header } from './components/Header.tsx';
import { UploadModule } from './components/UploadModule.tsx';
import { DocumentPreview } from './components/DocumentPreview.tsx';
import { ResultsDisplay } from './components/ResultsDisplay.tsx';
import { CollaborationArea } from './components/CollaborationArea.tsx';
import { RoleAssignmentModal } from './components/RoleAssignmentModal.tsx';
import { SessionInfo } from './components/SessionInfo.tsx';
import { FAQs } from './pages/FAQs.tsx';
// Import mock data as fallback
import mockResults from './assets/mock-results.json';

function Validator() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [qaEmail, setQaEmail] = useState('');
  const [techApproverEmail, setTechApproverEmail] = useState('');
  const [validationResults, setValidationResults] = useState<any>(null);
  const [streamProgress, setStreamProgress] = useState<{ evaluatedCriteria: number; totalCriteria: number } | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const openFileSelectorAfterConfirm = useRef(false);
  const rolesAreAssigned = qaEmail !== '' && techApproverEmail !== '';
  const isSessionLocked = isProcessing && !validationResults; // Only lock session during initial processing

  const handleUploadClick = () => {
    if (!rolesAreAssigned) {
      openFileSelectorAfterConfirm.current = true;
      setIsModalOpen(true);
    } else {
      fileInputRef.current?.click();
    }
  };

  const handleAssignRolesClick = () => {
    openFileSelectorAfterConfirm.current = false;
    setIsModalOpen(true);
  };

  const handleConfirmRoles = (qa: string, tech: string) => {
    setQaEmail(qa);
    setTechApproverEmail(tech);
    setIsModalOpen(false);
    if (openFileSelectorAfterConfirm.current) {
      fileInputRef.current?.click();
      openFileSelectorAfterConfirm.current = false;
    }
  };
  
  const handleModalCancel = () => {
    setIsModalOpen(false);
    openFileSelectorAfterConfirm.current = false;
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    setSelectedFile(file);
    setAnalysisComplete(false);
    setValidationResults(null);
    setApiError(null);
  };
  
  const handleProcess = async () => {
    if (!selectedFile) return;
    
    setApiError(null);
    setAnalysisComplete(false);
    setIsProcessing(true);
    setStreamProgress(null);
    
    // Set up a criteria map to store streaming results
    const criteriaMap = new Map();
    
    try {
      // Reset stream progress
      setStreamProgress(null);
      
      // Create form data for API call
      const formData = new FormData();
      formData.append('file', selectedFile);
      
      // Choose between streaming and non-streaming endpoints
      const useStreaming = false; // Set to true to use streaming, false to use the old approach
      
      if (useStreaming) {
        // Streaming approach using Server-Sent Events
        
        // Create a formdata and send the file via fetch POST first
        const uploadResponse = await fetch('http://localhost:5000/api/validate/stream', {
          method: 'POST',
          body: formData,
        });
        
        if (!uploadResponse.ok) {
          const errorData = await uploadResponse.json();
          throw new Error(errorData.detail || 'Failed to process document');
        }
        
        // Create a new EventSource after successful file upload
        const eventSource = new EventSource('http://localhost:5000/api/validate/stream');
        
        // Set up a buffer to accumulate full explanations
        let explanationBuffer = "";
        let currentCriterionId: string | null = null;
        
        // Listen for SSE events
        eventSource.onmessage = (event) => {
          const data = JSON.parse(event.data);
          
          // Handle different types of events
          switch (data.type) {
            case 'criteria_info':
              // When criteria info comes in, initialize our totalCriteria count
              const criteriaCount = streamProgress ? streamProgress.totalCriteria + 1 : 1;
              setStreamProgress({
                evaluatedCriteria: streamProgress ? streamProgress.evaluatedCriteria : 0,
                totalCriteria: criteriaCount
              });
              
              criteriaMap.set(data.id, {
                id: data.id,
                name: data.name,
                description: data.description,
                result: null, // Not yet determined
                fullExplanation: ""
              });
              // Update the UI with current criteria list
              setValidationResults({
                criteria: Array.from(criteriaMap.values())
              });
              
              // Update progress counter for the loader
              const evaluatedCriteriaCount = Array.from(criteriaMap.values()).filter(c => c.result !== null).length;
              setStreamProgress({
                evaluatedCriteria: evaluatedCriteriaCount,
                totalCriteria: criteriaMap.size
              });
              break;
              
            case 'token':
              // Add to the explanation buffer
              explanationBuffer += data.content;
              break;
              
            case 'criteria_update':
              // Update a criterion's result
              if (criteriaMap.has(data.id)) {
                const criterion = criteriaMap.get(data.id);
                criterion.result = data.result;
                // Try to extract the full explanation from the buffer for this criterion
                if (currentCriterionId !== data.id) {
                  if (currentCriterionId) {
                    // Save the buffer to the previous criterion
                    const prevCriterion = criteriaMap.get(currentCriterionId);
                    if (prevCriterion) {
                      prevCriterion.fullExplanation = explanationBuffer.trim();
                    }
                  }
                  // Start a new buffer for this criterion
                  explanationBuffer = "";
                  currentCriterionId = data.id;
                }
                
                // Update the UI with current criteria list
                setValidationResults({
                  criteria: Array.from(criteriaMap.values())
                });
                
                // Update progress counter for the loader
                const evaluatedCriteriaCount = Array.from(criteriaMap.values()).filter(c => c.result !== null).length;
                setStreamProgress({
                  evaluatedCriteria: evaluatedCriteriaCount,
                  totalCriteria: criteriaMap.size
                });
              }
              break;
              
            case 'complete':
              // Save the last buffer content
              if (currentCriterionId && criteriaMap.has(currentCriterionId)) {
                const criterion = criteriaMap.get(currentCriterionId);
                criterion.fullExplanation = explanationBuffer.trim();
              }
              
              // Final update with all criteria
              setValidationResults({
                criteria: Array.from(criteriaMap.values())
              });
              setAnalysisComplete(true);
              setIsProcessing(false);
              setStreamProgress(null); // Reset stream progress
              eventSource.close();
              break;
              
            case 'error':
              throw new Error(data.content || 'An error occurred during streaming');
          }
        };
        
        eventSource.onerror = (error) => {
          console.error('EventSource error:', error);
          eventSource.close();
          setApiError('Connection error during streaming');
          setIsProcessing(false);
        };
        
      } else {
        // Non-streaming approach (original implementation)
        const response = await fetch('http://localhost:5000/api/validate', {
          method: 'POST',
          body: formData,
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.detail || 'Failed to process document');
        }
        
        const data = await response.json();
        
        // Transform API results to match frontend expected format
        const transformedResults = {
          criteria: data.raw_results.criteria_results.map((item: any) => ({
            id: item.id,
            name: item.criterion,
            description: item.description,
            result: item.result === 'PASS',
            fullExplanation: item.explanation
          }))
        };
        
        setValidationResults(transformedResults);
        setAnalysisComplete(true);
        setIsProcessing(false);
      }
    } catch (error) {
      console.error('Error processing document:', error);
      setApiError(error instanceof Error ? error.message : 'An unknown error occurred');
      setIsProcessing(false);
    }
  };

  const processButtonIsDisabled = !selectedFile || !rolesAreAssigned || isProcessing;

  return (
    <>
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        onChange={handleFileChange}
        accept=".doc,.docx,.pdf"
      />
      {isModalOpen && (
        <RoleAssignmentModal
          onConfirm={handleConfirmRoles}
          onCancel={handleModalCancel}
          initialQaEmail={qaEmail}
          initialTechApproverEmail={techApproverEmail}
        />
      )}
      
      <div className="w-full py-5 space-y-5">
        <UploadModule
          selectedFile={selectedFile}
          onUploadClick={handleUploadClick}
          onProcess={handleProcess}
          isLocked={isSessionLocked}
          processDisabled={processButtonIsDisabled}
        />
        
        {apiError && (
          <div className="p-4 bg-red-100 text-red-700 rounded-md border border-red-300">
            <p className="font-semibold">Error:</p>
            <p>{apiError}</p>
          </div>
        )}
        
        <div className="flex flex-col lg:flex-row gap-6 w-full">
          <div className="w-full lg:w-3/5">
            <DocumentPreview file={selectedFile} />
          </div>
          <div className="w-full lg:w-2/5 flex flex-col gap-6">
            <ResultsDisplay 
              analysisComplete={analysisComplete} 
              results={analysisComplete ? (validationResults || mockResults) : validationResults}
              isProcessing={isProcessing}
              streamProgress={streamProgress}
            />
            <CollaborationArea analysisComplete={analysisComplete} />
          </div>
        </div>
        
        <SessionInfo
          qaEmail={qaEmail}
          techApproverEmail={techApproverEmail}
          onAssignRoles={handleAssignRolesClick}
        />
      </div>
    </>
  );
}

function App() {
  return (
    <div className="min-h-screen w-screen max-w-full bg-bh-light-gray font-sans overflow-x-hidden">
      <Header />
      <div className="w-full max-w-full px-2 sm:px-4 md:px-6 lg:px-8 xl:px-10 2xl:px-12">
        <Routes>
          <Route path="/" element={<Validator />} />
          <Route path="/FAQs" element={<FAQs />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;